-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2021 at 02:58 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ehr_appointment`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_appointment`
--

CREATE TABLE `tbl_appointment` (
  `appointment_id` int(11) NOT NULL,
  `patientEmail` varchar(200) NOT NULL,
  `patientName` varchar(200) NOT NULL,
  `patientMobile` varchar(20) NOT NULL,
  `doctorEmail` varchar(200) NOT NULL,
  `doctorName` varchar(200) NOT NULL,
  `doctorMobile` varchar(20) NOT NULL,
  `symptoms` text NOT NULL,
  `appointmentDate` varchar(45) NOT NULL,
  `appointmentTime` varchar(45) NOT NULL DEFAULT '00:00:00',
  `appointment_status` varchar(45) NOT NULL DEFAULT 'Not Viewed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_appointment`
--

INSERT INTO `tbl_appointment` (`appointment_id`, `patientEmail`, `patientName`, `patientMobile`, `doctorEmail`, `doctorName`, `doctorMobile`, `symptoms`, `appointmentDate`, `appointmentTime`, `appointment_status`) VALUES
(1, 'dinesh4u@gmail.com', 'Dinesh Ubale', '9503986854', 'ubaledinesh4u@gmail.com', 'Dinesh Ubale', '7350456969', 'cough and cold', 'Saturday, March 20, 2021', '11:15', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_labs`
--

CREATE TABLE `tbl_labs` (
  `lab_id` int(11) NOT NULL,
  `lab_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `latitude` varchar(45) NOT NULL,
  `longitude` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_labs`
--

INSERT INTO `tbl_labs` (`lab_id`, `lab_name`, `email`, `password`, `mobile`, `address`, `latitude`, `longitude`) VALUES
(1, 'Advait Laboratory', 'adi@gmail.com', '12345', '7350456969', 'Pune', '18.5597067', '73.9288177');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lab_appointment`
--

CREATE TABLE `tbl_lab_appointment` (
  `id` int(11) NOT NULL,
  `patient_id` varchar(45) NOT NULL,
  `lab_id` varchar(45) NOT NULL,
  `testDate` varchar(45) NOT NULL,
  `testTime` varchar(45) NOT NULL DEFAULT '00:00',
  `testStatus` varchar(45) NOT NULL DEFAULT 'Not Viewed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_lab_appointment`
--

INSERT INTO `tbl_lab_appointment` (`id`, `patient_id`, `lab_id`, `testDate`, `testTime`, `testStatus`) VALUES
(1, 'dinesh4u@gmail.com', 'adi@gmail.com', 'Friday, April 23, 2021', '08:44', 'Accepted'),
(3, 'dinesh4u@gmail.com', 'adi@gmail.com', 'Saturday, April 24, 2021', '10:36', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_medicine`
--

CREATE TABLE `tbl_medicine` (
  `medicine_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `medicine_name` varchar(45) NOT NULL,
  `morning` int(11) NOT NULL,
  `afternoon` int(11) NOT NULL,
  `evening` int(11) NOT NULL,
  `days` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_medicine`
--

INSERT INTO `tbl_medicine` (`medicine_id`, `appointment_id`, `medicine_name`, `morning`, `afternoon`, `evening`, `days`) VALUES
(1, 1, 'Paracetemol', 1, 0, 1, 5),
(2, 1, 'chest and cold', 1, 0, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reports`
--

CREATE TABLE `tbl_reports` (
  `report_id` int(11) NOT NULL,
  `patient_id` varchar(45) NOT NULL,
  `report_title` varchar(45) NOT NULL,
  `filename` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_reports`
--

INSERT INTO `tbl_reports` (`report_id`, `patient_id`, `report_title`, `filename`) VALUES
(1, 'dinesh4u@gmail.com', 'MRI Scan', 'input.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `user_type` varchar(45) NOT NULL,
  `specification` varchar(50) NOT NULL,
  `hospital_name` varchar(200) NOT NULL DEFAULT '',
  `latitude` varchar(20) NOT NULL,
  `longitude` varchar(20) NOT NULL,
  `user_status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `fname`, `lname`, `email`, `mobile`, `password`, `user_type`, `specification`, `hospital_name`, `latitude`, `longitude`, `user_status`) VALUES
(1, 'Dinesh', 'Ubale', 'ubaledinesh4u@gmail.com', '7350456969', '123456', 'Doctor', 'Heart Specialist', 'Sai Hospital', '18.5597067', '73.9288177', 0),
(2, 'Dinesh', 'Ubale', 'dinesh4u@gmail.com', '9503986854', '123456', 'Patient', '', '', '18.5604071', '73.9278533', 1),
(3, 'Advait', 'Lab', 'adi@gmail.com', '7350456969', '12345', 'Lab', '', 'Advait Lab', '18.5597067', '73.9288177', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_appointment`
--
ALTER TABLE `tbl_appointment`
  ADD PRIMARY KEY (`appointment_id`);

--
-- Indexes for table `tbl_labs`
--
ALTER TABLE `tbl_labs`
  ADD PRIMARY KEY (`lab_id`);

--
-- Indexes for table `tbl_lab_appointment`
--
ALTER TABLE `tbl_lab_appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_medicine`
--
ALTER TABLE `tbl_medicine`
  ADD PRIMARY KEY (`medicine_id`);

--
-- Indexes for table `tbl_reports`
--
ALTER TABLE `tbl_reports`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_appointment`
--
ALTER TABLE `tbl_appointment`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_labs`
--
ALTER TABLE `tbl_labs`
  MODIFY `lab_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_lab_appointment`
--
ALTER TABLE `tbl_lab_appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_medicine`
--
ALTER TABLE `tbl_medicine`
  MODIFY `medicine_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_reports`
--
ALTER TABLE `tbl_reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
